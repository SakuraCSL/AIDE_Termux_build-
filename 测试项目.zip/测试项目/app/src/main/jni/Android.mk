LOCAL_PATH := $(call my-dir)

include $(CLEAR_VARS)

LOCAL_MODULE    := HelloJni
LOCAL_SRC_FILES := hello-jni.c

LOCAL_CFLAGS := -w -s -Wno-error=format-security -fvisibility=hidden -fpermissive
LOCAL_LDLIBS := -llog -landroid

include $(BUILD_SHARED_LIBRARY)
