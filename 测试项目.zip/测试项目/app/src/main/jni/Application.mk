APP_ABI := armeabi-v7a arm64-v8a
APP_STL := c++_static
APP_OPTIM := release
APP_PIE := true
